document.write("This came from the attached Javascript file!<br/>");
document.write("Some think that attaching Javascript is the best way to use it with HTML!");